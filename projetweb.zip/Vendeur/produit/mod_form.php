<form action="" method="post">


	<table id="table">

		<tr>
			<th>Nom</th>
			<td><input type="text" name="nom" /></td>
		</tr> 

		<tr>
			<th>Description</th>
			<td><input type="text" name="desp" /></td>
		</tr> 

		<tr>
			<th>Quantite</th>
			<td><input type="number" name="qte" /></td>
		</tr> 

		<tr>
			<th>Prix</th>
			<td><input type="number" step="0.1" name="prix" /></td>
		</tr> 

	</table> 

	<input type="submit" value="Modifier">
</form>