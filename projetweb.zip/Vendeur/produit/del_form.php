<p>Are you sure ??? </p>
<form action="" method="post">
	<input type="submit" name="supprimer" value="Supprimer">
	<input type="submit" name="annuler" value="Annuler"> 
</form>