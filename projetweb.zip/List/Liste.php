<?php 
session_start();
$page_title = "Liste";
include("header.php");
?>

<div id="list">
	<h1> Liste </h1>


	<nav >
		<a href="../index.php">HOME</a>
		<a href="categories.php"> Categories </a> 
		<a href="list_produit.php"> Produits </a> 
		<a href="list_four.php"> Fournisseurs </a> 
		<a href="panier.php"> Panier </a>
	</nav>

</div>

<img src="upec1.JPG">






<?php
include("footer.php");
?>