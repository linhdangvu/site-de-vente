<form action="recherche.php" method="post"> 
	<input type="text" name="recherche" required>
	<input type="submit" value="Find produits">
</form>