<form action="find_cate.php" method="post"> 
	<input type="text" name="recherche" required>
	<input type="submit" value="Find categories">
</form>