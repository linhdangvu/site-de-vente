<form action="find_vendeur.php" method="post"> 
	<input type="text" name="recherche" required>
	<input type="submit" value="Find vendeur">
</form>